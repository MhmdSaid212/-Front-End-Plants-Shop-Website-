function toggleAnswer(element) {
    // Get the next sibling element, which is the answer div
    var answer = element.nextElementSibling;

    // Toggle the display of the answer
    if (answer.style.display === "block") {
        answer.style.display = "none";
    } else {
        answer.style.display = "block";
    }
}

const categoriesData = [
  [
    {
      title: "Orchids",
      description: "Orchids are easily everyones Favorite flowering plant, Find new orchids and orchids success items in this collection",
      image: "/images/moth_orchid.png",
    },
    {
      title: "Succulents",
      description: "Every cacti is succulent but not every succulent is cacti.One of the beautiful types of plants that doesn’t demand much care.",
      image: "/images/succulents_shutterstock_286576340-copy 1.png",
    },
    {
      title: "Pet-friendly",
      description: "Non-toxic plants safe for cats, dogs, and other pets, like spider plants and parlor palms.",
      image: "/images/pet-friendly-houseplants-beautifying-your-home-safely-317838.png",
    },
  ],
  [
    {
      title: "Drought Resistant",
      description: "Low-maintenance options such as cacti or succulents thrive in harsh conditions while adding a unique aesthetic to your garden.",
      image: "/images/cat4.png",
    },
    {
      title: "Flowering Shrubs",
      description: "Bring vibrant color to your garden with hardy flowering shrubs like hibiscus and bougainvillea. Perfect for creating a lively outdoor space.  ",
      image: "/images/cat5.png",
    },
    {
      title: "Trees",
      description: "Compact trees that add both greenery and functionality to outdoor spaces by producing fresh fruits.",
      image: "/images/cat6.png",
    },
  ],
  [
    {
      title: "Organic Compost",
      description: "Made from natural ingredients, organic compost enriches soil health and boosts plant growth sustainably.",
      image: "/images/cat7.png",
    },
    {
      title: "Liquid Fertilizer",
      description: "A fast-acting solution for leafy greens and flowers, liquid fertilizers ensure rapid nutrient absorption for flourishing plants.",
      image: "/images/cat8.png",
    },
    {
      title: "Slow Granules",
      description: "Ideal for long-term plant care, these granules gradually release essential nutrients to keep your plants healthy over time.",
      image: "/images/cat9.png",
    },
  ],
  [
    {
      title: "Ceramic Pots",
      description: "Stylish pots available in various designs and colors to complement your plants and enhance your outdoor décor.",
      image: "/images/cat10.png",
    },
    {
      title: "Gardening Tools",
      description: "Complete kits including trowels, pruners, and gloves to make planting and maintaining your garden a breeze.",
      image: "/images/cat11.png",
    },
    {
      title: "SelfWatering Pots",
      description: "Orchids are easily everyones Favorite flowering plant, Find new orchids and orchids success items in this collection",
      image: "/images/cat12.png",
    },
  ],
];

let currentIndex = 0;
const totalSlides = categoriesData.length;

const categoriesGrid = document.querySelector(".categories-grid");
const leftArrow = document.querySelector(".left-arrow");
const rightArrow = document.querySelector(".right-arrow");
const dots = document.querySelectorAll(".dot");

// تحديث العرض بناءً على الفهرس الحالي
function updateView() {
  categoriesGrid.classList.add("fade-out");

  setTimeout(() => {
    categoriesGrid.innerHTML = categoriesData[currentIndex]
      .map(
        (category) => `
        <div class="category-item">
          <img src="${category.image}" alt="${category.title}">
          <div class="category-info">
            <h1>${category.title}</h1>
            <p>${category.description}</p>
            <hr>
          </div>
          <button class="buy-now">Buy Now</button>
        </div>`
      )
      .join("");

    categoriesGrid.classList.remove("fade-out");
    categoriesGrid.classList.add("fade-in");

    dots.forEach((dot, index) => {
      dot.classList.toggle("active", index === currentIndex);
    });

    leftArrow.style.display = currentIndex === 0 ? "none" : "block";
    rightArrow.style.display = currentIndex === totalSlides - 1 ? "none" : "block";
  }, 300); 
}


leftArrow.addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex--;
    updateView();
  }
});

rightArrow.addEventListener("click", () => {
  if (currentIndex < totalSlides - 1) {
    currentIndex++;
    updateView();
  }
});

dots.forEach((dot, index) => {
  dot.addEventListener("click", () => {
    currentIndex = index;
    updateView();
  });
});

updateView();

let currentSetIndex = 0;
const testimonials = document.querySelectorAll(".testomonials-information > div");
const dotsT = document.querySelectorAll(".carousel-dotss .dotT");

const testimonialSets = [
  [
    {
      name: "Mariam Itani",
      description: "Their service was exceptional! The team transformed my garden into a serene oasis with stunning attention to detail.",
      image: "/images/selling-plants-1024x683 1.png"
    },
    {
      name: "John Doe",
      description: "From start to finish, Al Yasamina's team was fantastic. They transformed my vision into a beautiful, cohesive reality.",
      image: "/images/selling-plants-1024x683 2.png"
    },
    {
      name: "Jane Smith",
      description: "The Plant Doctor service revived my indoor plants, and their landscaping added new charm to my outdoor space.",
      image: "/images/selling-plants-1024x683 3.png"
    }
  ],
  [
    {
      name: "Ali Ahmad",
      description: "Choosing Al Yasamina was one of the best decisions. The team created a garden tailored to my style and needs.",
      image: "/images/selling-plants-1024x683 4.png"
    },
    {
      name: "Fatima Hassan",
      description: "Their services were top-notch! I especially loved how they paid attention to even the smallest details. They created a space that not only looks great but also feels welcoming and peaceful.",
      image: "/images/selling-plants-1024x683 5.png"
    },
    {
      name: "David Brown",
      description: "Their landscaping expertise transformed my backyard into a paradise. Now I enjoy my outdoor space more than ever.",
      image: "/images/selling-plants-1024x683 6.png"
    }
  ],
  [
    {
      name: "Sara Karim",
      description: "Al Yasamina brought life to my garden with their designs. The team was incredibly skilled and transformed my space.",
      image: "/images/selling-plants-1024x683 7.png"
    },
    {
      name: "Omar Khalil",
      description: "I was amazed at how they turned my backyard into a lively space. Their creative solutions made a huge difference.",
      image: "/images/selling-plants-1024x683 8.png"
    },
    {
      name: "Lina Chami",
      description: "The team took the time to understand my needs and delivered beyond expectations. Their passion was clear in every detail.",
      image: "/images/selling-plants-1024x683 9.png"
    }
  ],
  [
    {
      name: "Nour Youssef",
      description: "From start to finish, Al Yasamina's dedication and expertise made my dream garden a beautiful, lasting reality.",
      image: "/images/selling-plants-1024x683 10.png"
    },
    {
      name: "Ziad Taha",
      description: "They transformed my outdoor space into a beautiful retreat. I now receive compliments on the garden all the time!",
      image: "/images/selling-plants-1024x683 11.png"
    },
    {
      name: "Reem Bassil",
      description: "Their Plant Doctor service is a lifesaver! My plants are thriving, and my garden looks healthier than ever before.",
      image: "/images/selling-plants-1024x683 12.png"
    }
  ]
];


function updateTestimonials(setIndex) {
  testimonials.forEach((testimonial, i) => {
    const data = testimonialSets[setIndex][i];
    if (data) {
      testimonial.querySelector("h2").innerText = data.name;
      testimonial.querySelector("p").innerText = data.description;
      testimonial.querySelector("div").style.backgroundImage = `url(${data.image})`;
      testimonial.classList.add("active");
    } else {
      testimonial.classList.remove("active");
    }
  });
}

function switchTestimonialSet(index) {
  // Set the dots active state based on the index
  dotsT.forEach((dot, i) => {
    dot.classList.toggle("active", i === index);
  });

  // Remove the active class from all testimonials
  testimonials.forEach(testimonial => {
    testimonial.classList.remove("active");
  });

  // Add the active class to all testimonials in the selected set
  testimonialSets[index].forEach((_, i) => {
    testimonials[i].classList.add("active");
  });

  // Update the testimonial content (name, description, image)
  updateTestimonials(index);
}

function autoSlide() {
  currentSetIndex = (currentSetIndex + 1) % testimonialSets.length;
  switchTestimonialSet(currentSetIndex);
}

let sliderInterval = setInterval(autoSlide, 5000);

dotsT.forEach((dot, index) => {
  dot.addEventListener("click", () => {
    clearInterval(sliderInterval);
    currentSetIndex = index;
    switchTestimonialSet(index);
    sliderInterval = setInterval(autoSlide, 5000);
  });
});

switchTestimonialSet(currentSetIndex);




