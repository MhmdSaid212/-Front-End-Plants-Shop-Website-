// Selectors
const modal = document.getElementById('popup-modal');
const closeBtn = document.getElementById('close-popup');
const bookNowButtons = document.querySelectorAll('.learn-more');

// Dynamically Change Modal Content and Open Popup
bookNowButtons.forEach((button) => {
  button.addEventListener('click', (event) => {
    const serviceItem = event.target.closest('.service-item');
    const serviceTitle = serviceItem.querySelector('h1').textContent;
    const serviceImage = serviceItem.querySelector('img').src;

    // Update Modal Content
    modal.querySelector('h2').textContent = serviceTitle;
    modal.querySelector('.popup-image').src = serviceImage;

    // Show Modal
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
  });
});

// Close Popup when "X" is clicked
closeBtn.addEventListener('click', () => {
  modal.style.display = 'none';
  document.body.style.overflow = 'auto'; // Restore background scrolling
});

// Close Popup when clicking outside the content
window.addEventListener('click', (event) => {
  if (event.target === modal) {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto'; // Restore background scrolling
  }
});
