let questions = [];
let currentQuestionIndex = 0;
let score = 0;

// Fetch questions from Quiz.json
fetch("Quiz.json")
    .then((response) => {
        if (!response.ok) {
            throw new Error("Network response was not ok " + response.statusText);
        }
        return response.json();
    })
    .then((data) => {
        questions = data;
        loadQuestion(currentQuestionIndex);
    })
    .catch((error) => {
        console.error("Error fetching quiz data:", error);
    });

// Initialize the first question
function loadQuestion(index) {
    const container = document.querySelector(".container");
    const questionEl = document.querySelector(".question");
    const optionsContainer = document.querySelector(".options");

    // Fade out for smooth transition
    container.style.opacity = "0";

    // Update content after opacity reaches 0
    setTimeout(() => {
        questionEl.textContent = `Question ${index + 1}: ${questions[index].question}`;
        optionsContainer.innerHTML = "";

        questions[index].options.forEach((option) => {
            const label = document.createElement("label");
            label.className = "option";

            const input = document.createElement("input");
            input.type = "radio";
            input.name = "question";
            input.value = option;

            const span = document.createElement("span");
            span.textContent = option;

            label.appendChild(input);
            label.appendChild(span);
            optionsContainer.appendChild(label);
        });

        // Preselect the user's previous answer if it exists
        const previousAnswer = questions[index].selected;
        if (previousAnswer) {
            const optionToSelect = Array.from(document.querySelectorAll('input[name="question"]')).find(
                (input) => input.value === previousAnswer
            );
            if (optionToSelect) optionToSelect.checked = true;
        }

        updateButtonVisibilityAndText(index);
        container.style.opacity = "1"; // Fade back in
    }, 300); // Allow the fade-out transition to complete
}

// Update button visibility and text for "Next", "Back", and "See Results"
function updateButtonVisibilityAndText(index) {
    const nextButton = document.querySelector(".next-button");
    let backButton = document.querySelector(".back-button");

    // Add "Back Question" button dynamically if it doesn't exist
    if (!backButton) {
        backButton = document.createElement("button");
        backButton.className = "back-button"; // Use existing styles
        backButton.textContent = "Back Question";
        nextButton.parentNode.insertBefore(backButton, nextButton);

        // Add event listener to the "Back Question" button
        backButton.addEventListener("click", () => {
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                loadQuestion(currentQuestionIndex);
            }
        });
    }

    // Show or hide the "Back Question" button based on the current question index
    backButton.style.display = index === 0 ? "none" : "inline-block";

    // Update the "Next" button to "See Results" on the last question
    if (index === questions.length - 1) {
        nextButton.textContent = "See Results";
        nextButton.onclick = showResults;
    } else {
        nextButton.textContent = "Next Question";
        nextButton.onclick = handleNextQuestion;
    }
}

// Handle next question
function handleNextQuestion() {
    const selectedOption = document.querySelector('input[name="question"]:checked');
    if (!selectedOption) {
        showPopup("Please select an option before proceeding!");
        return;
    }

    // Save the user's answer
    questions[currentQuestionIndex].selected = selectedOption.value;

    // Check answer only when moving forward
    if (selectedOption.value === questions[currentQuestionIndex].correct) {
        score++;
    }

    currentQuestionIndex++;
    loadQuestion(currentQuestionIndex);
}

function showResults() {
    const container = document.querySelector(".container");
    const quizSection = document.querySelector(".Quiz");

    // Add transition to fade out quiz container
    container.style.transition = "opacity 0.5s ease";
    container.style.opacity = "0";

    // After the fade-out, display results
    setTimeout(() => {
        container.style.display = "none"; // Hide the quiz container after fade-out

        // Create and display the results screen
        const resultDiv = document.createElement("div");
        resultDiv.className = "result-screen";
        resultDiv.style.transition = "opacity 0.5s ease"; // Add transition for fade-in
        resultDiv.style.opacity = "0"; // Start hidden

        const heading = document.createElement("h2");
        heading.textContent = "You should probably buy one of these:";
        heading.style.textAlign = "center";

        const imageContainer = document.createElement("div");
        imageContainer.className = "image-container";
        imageContainer.style.display = "flex";
        imageContainer.style.justifyContent = "center";
        imageContainer.style.gap = "20px";

        const plants = [
            { name: "Peace Lily", img: "/images/sustainability-concept-with-plants-growing-from-geometric-forms.png" },
            { name: "Rubber Plant", img: "/images/potted-plant-alocasia-popular-houseplant.png" },
            { name: "Fiddle Leaf Fig", img: "/images/Group 69.png" },
        ];

        plants.forEach((plant) => {
            const plantDiv = document.createElement("div");
            const plantImg = document.createElement("img");
            plantImg.src = plant.img;
            plantImg.alt = plant.name;

            const plantName = document.createElement("p");
            plantName.textContent = plant.name;

            plantDiv.appendChild(plantImg);
            plantDiv.appendChild(plantName);

            imageContainer.appendChild(plantDiv);
        });

        const tryAgainButton = document.createElement("button");
        tryAgainButton.textContent = "Try Again";
        tryAgainButton.classList = "try-again-button";
        tryAgainButton.addEventListener("click", restartQuiz);

        resultDiv.appendChild(heading);
        resultDiv.appendChild(imageContainer);
        resultDiv.appendChild(tryAgainButton);

        quizSection.appendChild(resultDiv);

        // Trigger fade-in for the results screen
        setTimeout(() => {
            resultDiv.style.opacity = "1";
        }, 50); // Slight delay to ensure the element is added before opacity changes
    }, 500); // Wait for the fade-out transition to complete
}


// Restart the quiz
function restartQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    questions.forEach((question) => delete question.selected);

    const container = document.querySelector(".container");
    const resultScreen = document.querySelector(".result-screen");

    if (resultScreen) resultScreen.remove();

    container.style.display = "block";
    container.style.opacity = "1";

    loadQuestion(currentQuestionIndex);
}


// Function to display the popup
function showPopup(message) {
    const existingPopup = document.querySelector(".custom-popup");
    if (existingPopup) return; // Prevent multiple popups

    const popup = document.createElement("div");
    popup.className = "custom-popup";
    popup.style.position = "fixed";
    popup.style.top = "50%";
    popup.style.left = "50%";
    popup.style.transform = "translate(-50%, -50%)";
    popup.style.padding = "20px";
    popup.style.backgroundColor = "#fff";
    popup.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
    popup.style.borderRadius = "10px";
    popup.style.textAlign = "center";
    popup.style.zIndex = "1000";

    const messageEl = document.createElement("p");
    messageEl.textContent = message;
    messageEl.style.marginBottom = "10px";

    const closeButton = document.createElement("button");
    closeButton.textContent = "Close";
    closeButton.style.padding = "10px 20px";
    closeButton.style.backgroundColor = "#4EBF4A";
    closeButton.style.color = "#fff";
    closeButton.style.border = "none";
    closeButton.style.borderRadius = "5px";
    closeButton.style.cursor = "pointer";

    closeButton.addEventListener("click", () => {
        popup.remove();
    });

    popup.appendChild(messageEl);
    popup.appendChild(closeButton);
    document.body.appendChild(popup);
} 