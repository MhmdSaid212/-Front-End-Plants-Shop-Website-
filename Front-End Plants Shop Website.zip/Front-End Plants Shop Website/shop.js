document.addEventListener("DOMContentLoaded", () => {
  const priceMinSlider = document.getElementById("price-range-min");
  const priceMaxSlider = document.getElementById("price-range-max");
  const priceMinLabel = document.getElementById("price-range-label-min");
  const priceMaxLabel = document.getElementById("price-range-label-max");

  const shopProductsDiv = document.querySelector(".shop-products");
  const paginationDiv = document.querySelector(".pagination");
  const toggleIcons = document.querySelectorAll(".toggle-icon");
  const filterCheckboxes = document.querySelectorAll(".checkbox-container input[type='checkbox']");
  const cartCountElement = document.getElementById("cart-count");
  const sortFilter = document.getElementById("sort-filter");
  const searchIcon = document.querySelector(".bi-search");
  const iconsContainer = document.querySelector(".icons"); // Target .icons container
  const itemsPerPage = 9;

  let currentPage = 1;
  let products = [];
  let filteredProducts = [];
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Create Search Input and Results Container
  const searchInput = document.createElement("input");
  const searchResultsContainer = document.createElement("div");

  searchInput.type = "text";
  searchInput.placeholder = "Search";
  searchInput.classList.add("search-input");
  searchResultsContainer.classList.add("search-results");

  document.body.appendChild(searchResultsContainer);

  // Update Cart Count
  const updateCartCount = () => {
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountElement.textContent = totalCount;
  };

  // Add to Cart
  const addToCart = (product) => {
    const existingProduct = cart.find((item) => item.id === product.id);
    if (existingProduct) {
      existingProduct.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
  };

  const renderProducts = () => {
    shopProductsDiv.innerHTML = "";
  
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, filteredProducts.length);
    const currentProducts = filteredProducts.slice(startIndex, endIndex);
  
    if (currentProducts.length === 0) {
      shopProductsDiv.innerHTML = "<p>No products match the filters.</p>";
      return;
    }
  
    currentProducts.forEach((product) => {
      const productCard = document.createElement("div");
      productCard.classList.add("product-card");
      productCard.innerHTML = `
        <img src="${product.image}" alt="${product['Plant-name']}" class="product-image">
        <h3 class="product-name">${product['Plant-name']}</h3>
        <p class="product-description">${product.description}</p>
        <p class="product-price">Price: ${product.price}</p>
        <button class="cart-button" data-id="${product.id}">Add to Cart</button>
      `;
  
      // Add click event listener to navigate to product.html
      productCard.addEventListener("click", () => {
        // Construct URL with query parameter for the product ID
        window.location.href = `/product.html?id=${product.id}`;
      });
  
      shopProductsDiv.appendChild(productCard);
    });
  
    // Prevent navigation when clicking "Add to Cart"
    document.querySelectorAll(".cart-button").forEach((button) => {
      button.addEventListener("click", (event) => {
        event.stopPropagation(); // Prevent parent card click event
        const productId = button.dataset.id;
        const product = filteredProducts.find((item) => item.id === productId);
        addToCart(product);
      });
    });
  };
  

  // Render Pagination
  const renderPagination = () => {
    paginationDiv.innerHTML = "";

    const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);

    if (totalPages <= 1) return;

    if (currentPage > 1) {
      const prevButton = document.createElement("button");
      prevButton.textContent = "Previous";
      prevButton.classList.add("page-button");
      prevButton.addEventListener("click", () => {
        currentPage--;
        renderProducts();
        renderPagination();
      });
      paginationDiv.appendChild(prevButton);
    }

    for (let i = 1; i <= totalPages; i++) {
      const pageButton = document.createElement("button");
      pageButton.textContent = i;
      pageButton.classList.add("page-button");
      if (i === currentPage) pageButton.classList.add("active");
      pageButton.addEventListener("click", () => {
        currentPage = i;
        renderProducts();
        renderPagination();
      });
      paginationDiv.appendChild(pageButton);
    }

    if (currentPage < totalPages) {
      const nextButton = document.createElement("button");
      nextButton.textContent = "Next";
      nextButton.classList.add("page-button");
      nextButton.addEventListener("click", () => {
        currentPage++;
        renderProducts();
        renderPagination();
      });
      paginationDiv.appendChild(nextButton);
    }
  };

  // Search Functionality
searchIcon.addEventListener("click", () => {
  const searchWrapper = document.createElement("div");
  searchWrapper.classList.add("search-wrapper");
  searchWrapper.style.display = "inline-block"; // Ensure it stays in line with other icons

  searchInput.style.width = "150px"; // Adjust width as needed
  searchWrapper.appendChild(searchInput);
  searchWrapper.appendChild(searchResultsContainer); // Append search results container to search wrapper

  iconsContainer.replaceChild(searchWrapper, searchIcon); // Replace the icon with the input field
  searchInput.focus();
});

searchInput.addEventListener("input", () => {
  const searchTerm = searchInput.value.toLowerCase().trim();

  // Hide results if input is empty
  if (searchTerm === "") {
    searchResultsContainer.style.display = "none";
    searchResultsContainer.innerHTML = "";
    return;
  }

  // Filter products by the search term
  const searchResults = products.filter((product) =>
    product["Plant-name"].toLowerCase().includes(searchTerm)
  );

  // Clear and update the search results container
  searchResultsContainer.innerHTML = "";
  if (searchResults.length > 0) {
    searchResultsContainer.style.display = "block"; // Show the container
    searchResults.forEach((product) => {
      const resultItem = document.createElement("div");
      resultItem.classList.add("search-result-item");
      resultItem.innerHTML = `
        <img src="${product.image}" alt="${product['Plant-name']}" class="result-image">
        <p class="result-name">${product['Plant-name']}</p>
      `;
      
      // Add click event to navigate to product.html with the product ID
      resultItem.addEventListener("click", () => {
        window.location.href = `/product.html?id=${product.id}`;
      });

      searchResultsContainer.appendChild(resultItem);
    });
  } else {
    searchResultsContainer.style.display = "none"; // Hide if no results
  }
});




  // Apply Sorting
  const applySorting = (sortOption) => {
    switch (sortOption) {
      case "price-high-low":
        filteredProducts.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
        break;
      case "price-low-high":
        filteredProducts.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
        break;
      case "alphabetical-a-z":
        filteredProducts.sort((a, b) => a["Plant-name"].localeCompare(b["Plant-name"]));
        break;
      case "alphabetical-z-a":
        filteredProducts.sort((a, b) => b["Plant-name"].localeCompare(a["Plant-name"]));
        break;
    }
    currentPage = 1;
    renderProducts();
    renderPagination();
  };

  const filterProducts = () => {
    const minPrice = parseInt(priceMinSlider.value);
    const maxPrice = parseInt(priceMaxSlider.value);

    const activeCategoryButton = document.querySelector(".category-button.active");
    const activeCategory = activeCategoryButton ? activeCategoryButton.textContent : null;

    const selectedFilters = Array.from(filterCheckboxes)
      .filter((checkbox) => checkbox.checked)
      .map((checkbox) => checkbox.value);

    filteredProducts = products.filter((product) => {
      const productPrice = parseFloat(product.price.replace("$", ""));
      const matchesPrice = productPrice >= minPrice && productPrice <= maxPrice;

      const matchesCategory = !activeCategory || product.category === activeCategory;

      const matchesFilters = selectedFilters.every((filter) =>
        ["lightRequirement", "wateringNeeds", "size", "petFriendly", "color", "plantType"].some(
          (property) => product[property] === filter
        )
      );

      return matchesPrice && matchesCategory && matchesFilters;
    });

    currentPage = 1;
    renderProducts();
    renderPagination();
  };

   // Toggle functionality for all filter sections
   toggleIcons.forEach((icon) => {
    const contentContainer = icon.parentElement.nextElementSibling; // Find the corresponding content container

    // Add click listener to toggle visibility
    icon.addEventListener("click", () => {
      if (contentContainer.style.maxHeight) {
        // Collapse this section
        contentContainer.style.maxHeight = null;
        icon.innerHTML = `<path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/>`; // Set to the "plus" SVG
      } else {
        toggleIcons.forEach((otherIcon) => {
          const otherContentContainer =
            otherIcon.parentElement.nextElementSibling;
          if (otherContentContainer.style.maxHeight) {
            otherContentContainer.style.maxHeight = null;
            otherIcon.innerHTML = `<path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/>`; // Set to "plus" SVG
          }
        });

        // Expand this section
        contentContainer.style.maxHeight =
          contentContainer.scrollHeight + "px"; // Dynamically set height
        icon.innerHTML = `<path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z"/>`; // Set to "minus" SVG
      }
    });
  });

  fetch("shop.json")
    .then((response) => {
      if (!response.ok) throw new Error("Failed to fetch products");
      return response.json();
    })
    .then((data) => {
      products = data.project;
      filteredProducts = products;
      renderProducts();
      renderPagination();
    })
    .catch((error) => console.error("Error loading products:", error));

  priceMinSlider.addEventListener("input", () => {
    priceMinLabel.textContent = `$${priceMinSlider.value}`;
    filterProducts();
  });

  priceMaxSlider.addEventListener("input", () => {
    priceMaxLabel.textContent = `$${priceMaxSlider.value}`;
    filterProducts();
  });

  sortFilter.addEventListener("change", (event) => {
    applySorting(event.target.value);
  });

  filterCheckboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", filterProducts);
  });

  const categoryButtons = document.querySelectorAll(".category-button");
  categoryButtons.forEach((button) => {
    button.addEventListener("click", () => {
      categoryButtons.forEach((btn) => btn.classList.remove("active"));
      button.classList.add("active");
      filterProducts();
    });
  });

  const cartIcon = document.querySelector(".bi-cart");
  cartIcon.addEventListener("click", () => {
    window.location.href = "cart.html";
  });

  updateCartCount();
});
