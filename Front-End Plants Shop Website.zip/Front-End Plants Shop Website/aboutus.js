fetch('aboutus.json')
    .then(response => response.json()) 
    .then(contentData => {
        

        // About Us Section
        document.getElementById('para1').textContent = contentData.aboutUs.para1;
        document.getElementById('para2').textContent = contentData.aboutUs.para2;

        // Why Choose Us Section
        document.getElementById('para3').textContent = contentData.whyChooseUs.para3;
        document.getElementById('para4').textContent = contentData.whyChooseUs.para4;

        // Get In Touch Section
        document.getElementById('para5').textContent = contentData.getInTouch.para5;
        document.getElementById('para6').textContent = contentData.getInTouch.para6;

        // Contact Info Section
        document.getElementById('para7').textContent = contentData.contactInfo.callUs;
        document.getElementById('para8').textContent = contentData.contactInfo.callDetails;
        document.getElementById('para9').innerHTML = `<img src="${contentData.images.phoneIcon}" alt="phone icon" id="phoneic">${contentData.contactInfo.phoneNumber}`;
        document.getElementById('para10').textContent = contentData.contactInfo.visitUs;
        document.getElementById('para11').textContent = contentData.contactInfo.visitDetails;
        document.getElementById('para12').innerHTML = `<img src="${contentData.images.locationIcon}" alt="location icon" id="locationic">${contentData.contactInfo.location}`;

        // Set images
        document.getElementById('potImage').src = contentData.images.potImage;
        document.getElementById('flowersImage').src = contentData.images.flowersImage;

        const selectElement = document.getElementById('interestSelect');
        contentData.contactForm.options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option;
            opt.textContent = option;
            selectElement.appendChild(opt);
        });
    })
    .catch(error => {
        console.error('Error loading the JSON data:', error);
    });

    const interestSelect = document.getElementById('interestSelect');
    const arrow = document.getElementById('arrow23');
    
    // Add event listener for when the dropdown is clicked or focused
    interestSelect.addEventListener('click', function () {
      interestSelect.classList.add('opened'); // Adds the 'opened' class to trigger the arrow flip
    });
    
    // Add event listener for when an option is selected
    interestSelect.addEventListener('change', function () {
      interestSelect.classList.remove('opened'); // Removes the 'opened' class after a selection
    });
    
    // Optional: If you want the dropdown to reset when it loses focus
    interestSelect.addEventListener('blur', function () {
      interestSelect.classList.remove('opened'); // Removes the 'opened' class when the dropdown loses focus
    });
   
        
