document.addEventListener("DOMContentLoaded", () => {
    const toSignup = document.getElementById("to-signup");
    const toLogin = document.getElementById("to-login");
    const dropdown = document.getElementById("dropdown");
    const loginForm = document.querySelector(".login-container");
    const signupForm = document.querySelector(".signup-container");
    const rightImage = document.querySelector(".right");
    const leftImage = document.querySelector(".left");

    toSignup.addEventListener("click", (e) => {
        e.preventDefault();

        setTimeout(() => {
            loginForm.style.opacity = "0";
            loginForm.style.visibility = "hidden";
            signupForm.style.opacity = "1";
            signupForm.style.visibility = "visible";
        }, 1); // Delay to match flip timing

        // Flip images
        rightImage.style.opacity = "0";
        rightImage.style.visibility = "hidden";
        leftImage.style.opacity = "1";
        leftImage.style.visibility = "visible";
        dropdown.style.opacity = "0";
        dropdown.style.visibility = "hidden";
    });

    toLogin.addEventListener("click", (e) => {
        e.preventDefault();

        setTimeout(() => {
            signupForm.style.opacity = "0";
            signupForm.style.visibility = "hidden";
            loginForm.style.opacity = "1";
            loginForm.style.visibility = "visible";
        }, 1); // Delay to match flip timing

        // Flip images back
        leftImage.style.opacity = "0";
        leftImage.style.visibility = "hidden";
        rightImage.style.opacity = "1";
        rightImage.style.visibility = "visible";
        dropdown.style.opacity = "1";
        dropdown.style.visibility = "visible";
    });
});
