document.addEventListener("DOMContentLoaded", () => {
    const counter = document.getElementById("counter");
    const increaseBtn = document.getElementById("increase-btn");
    const decreaseBtn = document.getElementById("decrease-btn");
    const addToCartBtn = document.querySelector(".add-to-cart");
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get("id");
  
    let count = 1;
  
    // Counter functionality
    increaseBtn.addEventListener("click", () => {
      count++;
      counter.textContent = count;
      decreaseBtn.disabled = count <= 1; // Enable "-" button
    });
  
    decreaseBtn.addEventListener("click", () => {
      if (count > 1) {
        count--;
        counter.textContent = count;
      }
      decreaseBtn.disabled = count <= 1; // Disable "-" button if count <= 1
    });
  
    decreaseBtn.disabled = count <= 1;
  
    // Fetch product data
    fetch("/shop.json")
      .then((response) => response.json())
      .then((data) => {
        const product = data.project.find((item) => item.id === productId);
        if (product) {
          document.querySelector(".product-name").textContent = product["Plant-name"];
          document.querySelector(".product-image").src = product.image;
          document.querySelector(".product-description").textContent = product.description;
          document.querySelector(".product-price").textContent = `Price: ${product.price}`;
  
          // Add to Cart functionality
          addToCartBtn.addEventListener("click", () => {
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            const existingProduct = cart.find((item) => item.id === product.id);
  
            if (existingProduct) {
              existingProduct.quantity += count; // Increment quantity if already in the cart
            } else {
              cart.push({ ...product, quantity: count }); // Add product with quantity
            }
  
            localStorage.setItem("cart", JSON.stringify(cart));
            alert("Product added to cart!");
          });
        } else {
          document.querySelector(".product-details").innerHTML = "<p>Product not found.</p>";
        }
      })
      .catch((error) => console.error("Error loading product:", error));
  });
  