document.addEventListener("DOMContentLoaded", () => {
  const cartItemsContainer = document.getElementById("cart-items");
  const subtotalElement = document.getElementById("subtotal-value");
  const shippingElement = document.getElementById("shipping-value");
  const totalPriceElement = document.getElementById("total-price");
  const confirmButton = document.querySelector(".confirm-payment-btn");
  const itemCountElement = document.querySelector(".display-number-items");

  const nameInput = document.getElementById("name");
  const cardNumberInput = document.getElementById("card-number");
  const expiryInput = document.getElementById("expiry");
  const cvvInput = document.getElementById("cvv");

  const shippingCost = 2; // Fixed shipping cost
  const cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Helper: Display error message
  const displayError = (inputElement, message) => {
    let errorElement = inputElement.nextElementSibling;
    if (!errorElement || !errorElement.classList.contains("error-message")) {
      errorElement = document.createElement("span");
      errorElement.classList.add("error-message");
      errorElement.style.color = "red";
      inputElement.parentElement.appendChild(errorElement);
    }
    errorElement.textContent = message;
  };

  // Helper: Clear error message
  const clearError = (inputElement) => {
    const errorElement = inputElement.nextElementSibling;
    if (errorElement && errorElement.classList.contains("error-message")) {
      errorElement.textContent = "";
    }
  };

  // Helper: Show success popup
  const showSuccessPopup = () => {
    const popup = document.createElement("div");
    popup.classList.add("success-popup");
    popup.style.position = "fixed";
    popup.style.top = "50%";
    popup.style.left = "50%";
    popup.style.transform = "translate(-50%, -50%)";
    popup.style.padding = "20px";
    popup.style.backgroundColor = "#4CAF50";
    popup.style.color = "white";
    popup.style.borderRadius = "10px";
    popup.style.textAlign = "center";
    popup.style.zIndex = "1000";
    popup.textContent = "Payment confirmed successfully!";

    document.body.appendChild(popup);

    setTimeout(() => {
      document.body.removeChild(popup);
    }, 3000); // Remove popup after 3 seconds
  };

  // Render Cart
  const renderCart = () => {
    cartItemsContainer.innerHTML = ""; // Clear previous content
    let totalPrice = 0;
    let itemCount = 0;

    if (cart.length === 0) {
      cartItemsContainer.innerHTML = "<p>Your cart is empty!</p>";
      subtotalElement.textContent = "$0.00";
      shippingElement.textContent = "$0.00";
      totalPriceElement.textContent = "$0.00";
      confirmButton.querySelector("span").textContent = "$0.00";
      itemCountElement.textContent = "You have 0 items in your cart";
      return;
    }

    cart.forEach((item, index) => {
      const itemTotal = parseFloat(item.price) * item.quantity;
      totalPrice += itemTotal;
      itemCount += item.quantity;

      const itemDiv = document.createElement("div");
      itemDiv.classList.add("cart-item");

      itemDiv.innerHTML = `
        <div class="item-info">
          <img src="${item.image}" alt="${item['Plant-name']}">
          <h3>${item['Plant-name']}</h3>
        </div>
        <div class="item-actions">
          <div class="quantity-controls">
            <button class="decrease-quantity" data-index="${index}">-</button>
            <span>${item.quantity}</span>
            <button class="increase-quantity" data-index="${index}">+</button>
          </div>
          <span class="item-price">$${itemTotal.toFixed(2)}</span>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="remove-item" data-index="${index}"><!--!Font Awesome Free 6.7.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M170.5 51.6L151.5 80l145 0-19-28.4c-1.5-2.2-4-3.6-6.7-3.6l-93.7 0c-2.7 0-5.2 1.3-6.7 3.6zm147-26.6L354.2 80 368 80l48 0 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-8 0 0 304c0 44.2-35.8 80-80 80l-224 0c-44.2 0-80-35.8-80-80l0-304-8 0c-13.3 0-24-10.7-24-24S10.7 80 24 80l8 0 48 0 13.8 0 36.7-55.1C140.9 9.4 158.4 0 177.1 0l93.7 0c18.7 0 36.2 9.4 46.6 24.9zM80 128l0 304c0 17.7 14.3 32 32 32l224 0c17.7 0 32-14.3 32-32l0-304L80 128zm80 64l0 208c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-208c0-8.8 7.2-16 16-16s16 7.2 16 16zm80 0l0 208c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-208c0-8.8 7.2-16 16-16s16 7.2 16 16zm80 0l0 208c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-208c0-8.8 7.2-16 16-16s16 7.2 16 16z"/></svg>
        </div>
      `;

      

      cartItemsContainer.appendChild(itemDiv);
    });

    const subtotal = totalPrice.toFixed(2);
    const total = (totalPrice + shippingCost).toFixed(2);

    subtotalElement.textContent = `$${subtotal}`;
    shippingElement.textContent = `$${shippingCost.toFixed(2)}`;
    totalPriceElement.textContent = `$${total}`;
    confirmButton.querySelector("span").textContent = `$${total}`;
    itemCountElement.textContent = `You have ${itemCount} item${itemCount > 1 ? "s" : ""} in your cart`;
  };

  // Handle Cart Actions
  cartItemsContainer.addEventListener("click", (event) => {
    const index = event.target.dataset.index;

    if (event.target.classList.contains("increase-quantity")) {
      cart[index].quantity += 1;
    } else if (event.target.classList.contains("decrease-quantity")) {
      cart[index].quantity -= 1;
      if (cart[index].quantity <= 0) cart.splice(index, 1); // Remove item if quantity is 0
    } else if (event.target.classList.contains("remove-item")) {
      cart.splice(index, 1); // Remove item from cart
    }

    localStorage.setItem("cart", JSON.stringify(cart)); // Update localStorage
    renderCart(); // Re-render the cart
  });

  // Confirm Payment Button Error Handling
  confirmButton.addEventListener("click", (event) => {
    event.preventDefault(); // Prevent form submission

    let valid = true;

    // Validate Name
    if (!nameInput.value.trim()) {
      displayError(nameInput, "Name on card is required.");
      valid = false;
    } else {
      clearError(nameInput);
    }

    // Validate Card Number
    if (!cardNumberInput.value.trim() || !/^(\d{4} \d{4} \d{4} \d{4})$/.test(cardNumberInput.value)) {
      displayError(cardNumberInput, "Card number must be in the format XXXX XXXX XXXX XXXX.");
      valid = false;
    } else {
      clearError(cardNumberInput);
    }

    // Validate Expiry
    if (!expiryInput.value.trim() || !/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryInput.value)) {
      displayError(expiryInput, "Expiry date must be in MM/YY format.");
      valid = false;
    } else {
      clearError(expiryInput);
    }

    // Validate CVV
    if (!cvvInput.value.trim() || !/^\d{3}$/.test(cvvInput.value)) {
      displayError(cvvInput, "CVV must be 3 digits.");
      valid = false;
    } else {
      clearError(cvvInput);
    }

    if (valid) {
      // Show success popup
      showSuccessPopup();

      // Clear input fields
      nameInput.value = "";
      cardNumberInput.value = "";
      expiryInput.value = "";
      cvvInput.value = "";

      // Clear the cart and localStorage
      localStorage.removeItem("cart");
      cart.length = 0;

      // Re-render the cart
      renderCart();
    }
  });

  renderCart(); // Initial render
});
