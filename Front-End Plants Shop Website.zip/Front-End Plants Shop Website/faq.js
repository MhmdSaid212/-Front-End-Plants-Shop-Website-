fetch('faq.json')
            .then(response => response.json())
            .then(data => {
                document.getElementById('main-title').textContent = data.title2.main;
                document.getElementById('sub-title').textContent = data.title2.sub;
                document.getElementById('sub2-title').textContent = data.title2.sub2;
                const buttonContainer = document.createElement('div');
                buttonContainer.classList.add('button-container2');
            
                data.buttons2.forEach(button => {
                  const btn = document.createElement('a');
                  btn.href = button.link;
                  btn.textContent = button.label;
                  btn.classList.add('faq-button2');
                  buttonContainer.appendChild(btn);
                });
            
                document.querySelector('.main-container0').appendChild(buttonContainer);
            
                // Render FAQs
                const faqContainer = document.getElementById('faq-container2');
                data.faqs2.forEach(item => {
                  const faqItem = document.createElement('div');
                  faqItem.classList.add('faq-item1');
            
                  faqItem.innerHTML = `
                    <div class="question2">${item.questions} 
                    <div class="arrows12"> &#11208;</div>
                    </div>
                    <div class="answer2">${item.answers}</div>
                  `;
                  faqContainer.appendChild(faqItem);
                });

               
              });